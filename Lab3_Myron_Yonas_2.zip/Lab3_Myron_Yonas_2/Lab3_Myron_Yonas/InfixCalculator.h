#ifndef INFIXCALCULATOR_H
#define INFIXCALCULATOR_H

#include "Stacks.h"
#include <iostream>
#include <string>

using namespace std;

class Infixcalc
{
private:
	Stack<char>opStack;
	Stack<int>valStack;
	char operand1;
	char operand2;
	char op;
	int result;
	string infixExp;
	char ch;
	int a;
public:
	Infixcalc();
	Infixcalc(string);
	char check(char);
	int precedence(char);
	int math(char, int, int);
	int calculate();
	string getinfixExp();
	int getresult();
	bool isInfixExpValid(string);
};
Infixcalc::Infixcalc(){}
Infixcalc::Infixcalc(string input)
{
	infixExp = input;
}

bool Infixcalc::isInfixExpValid(string exp)//check if an infix expression is valid
{
	char n,m,k;
	int openBracket=0;
	for (int i = 0; exp[i] != '\0'; i++)
	{
		n = check(exp[i]);
		m = check(exp[i+1]);
		if (i == 0)
			k = '5';
		else
			k = check(exp[i-1]);

		if (n == '5')
			return false;
		else if (n == '3')  
		{
			if (m == '1'||m =='3')
			{
				openBracket++;
				continue;
			}
			else
				return false;
		}
		else if (n == '1')
		{
			if (exp[i + 1] == '\0' || m == '2' || m == '4')
				continue;
			else
				return false;
		}
		else if (n == '2')
		{
			if (i == 0 || exp[i + 1] == '\0')
				return false;
			else if (exp[i] == '/' && exp[i + 1] == '0')
				return false;
			else if (k == '1' || k == '4')
				if (m == '1' || m == '3')
					continue;
				else
					return false;
			else
				return false;
		}
		else if (n == '4')
		{
			if (openBracket)
			{
				openBracket--;
				continue;
			}
			else     //more closing brackets than opening brackets
				return false;
		}
	}
	if (openBracket > 0)//more opening brackets than closing brackets
		return false;
	else
		return true;
}
char Infixcalc::check(char a)
{
	if (a == '0' || a == '1' || a == '2' || a == '3' || a == '4' || a == '5' || a == '6' || a == '7' || a == '8' || a == '9')
	{
		return '1';
	}
	else if (a == '+' || a == '-' || a == '*' || a == '/')
	{
		return '2';
	}
	else if (a == '(')
	{
		return '3';
	}
	else if (a == ')')
	{
		return '4';
	}
	else//for invalid expression
	{
		return '5';
	}
}
int Infixcalc::precedence(char a)
{
	if ((a == '(') || (a == ')'))
	{
		return 0;
	}
	if ((a == '+') || (a == '-'))
	{
		return 1;
	}
	if ((a == '*') || (a == '/'))
	{
		return 2;
	}
}
int Infixcalc::math(char opr, int a, int b)
{
	if (opr == '-')
	{
		return a - b;
	}
	else if (opr == '+')
	{
		return a + b;
	}
	else if (opr == '*')
	{
		return a*b;
	}
	else if (opr == '/')
	{
		return a / b;
	}
}
int Infixcalc::calculate()
{
	char c;
	for (int i = 0; ch = infixExp[i]; i++)
	{
		 c = check(ch);
		switch (c)
		{
		case '1':
			a = ch - 48;//convert char to int
			valStack.push(a);
			break;
		case  '3':
			opStack.push(ch);
			break;
		case '2':
			if (opStack.listlength() == 0)
			{
				opStack.push(ch);

			}
			else if (precedence(ch) > precedence(opStack.peek()))
			{
				opStack.push(ch);
			}
			else
			{
				while ((opStack.listlength() == 1) && (precedence(ch) <= precedence(opStack.peek())))
				{

					operand2 = valStack.peek();
					valStack.pop();
					operand1 = valStack.peek();
					valStack.pop();
					op = opStack.peek();
					opStack.pop();
					result = math(op, operand1, operand2);
					valStack.push(result);
					

				}
				opStack.push(ch);
			}
			break;
		case '4':

			while (opStack.peek() != '(')
			{
				operand2 = valStack.peek();
				valStack.pop();
				operand1 = valStack.peek();
				valStack.pop();
				op = opStack.peek();
				opStack.pop();
				result = math(op, operand1, operand2);
				valStack.push(result);
			}
			opStack.pop();
			break;
		case '5':
			cout << "Expression is invalid." << endl;
			return 0;
			break;
		}
		
	}

	while (opStack.listlength() == 1)
	{
		operand2 = valStack.peek();
		valStack.pop();
		operand1 = valStack.peek();
		valStack.pop();
		op = opStack.peek();
		opStack.pop();
		result = math(op, operand1, operand2);
		valStack.push(result);
	}
	cout << "result is: " << result << endl;
	return result;
}
string Infixcalc::getinfixExp()
{
	return infixExp;
}
int Infixcalc::getresult()
{
	return result;
}


#endif